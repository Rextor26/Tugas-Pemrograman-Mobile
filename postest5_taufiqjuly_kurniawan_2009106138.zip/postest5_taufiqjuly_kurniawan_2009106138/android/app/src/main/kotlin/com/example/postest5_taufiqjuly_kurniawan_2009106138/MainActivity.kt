package com.example.postest5_taufiqjuly_kurniawan_2009106138

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
