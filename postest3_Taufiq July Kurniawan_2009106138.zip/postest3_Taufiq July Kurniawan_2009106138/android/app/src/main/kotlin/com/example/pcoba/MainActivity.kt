package com.example.pcoba

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
