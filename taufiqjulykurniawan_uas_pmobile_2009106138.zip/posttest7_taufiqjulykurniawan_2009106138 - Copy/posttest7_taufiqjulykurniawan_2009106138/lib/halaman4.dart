import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pertemuan7_crud/controller.dart';
import 'package:pertemuan7_crud/detail1.dart';

import 'package:pertemuan7_crud/halaman1.dart';
import 'package:pertemuan7_crud/halaman2.dart';

import 'package:pertemuan7_crud/main_page.dart';
import 'package:pertemuan7_crud/profil.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Second(),
    );
  }
}

class Second extends StatefulWidget {
  const Second({Key? key}) : super(key: key);

  @override
  State<Second> createState() => _Second();
}

Widget MyGambar() {
  return Row(
    children: [
      myImage(),
      MyImage1(),
      MyImage2(),
      MyImage3(),
      MyImage4(),
      MyImage5(),
      MyImage6(),
      MyImage7(),
      MyImage8(),
      MyImage9(),
      MyImage10(),
      MyImage11(),
    ],
  );
}

Widget Myic(BuildContext context) {
  return Container(
    child: Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20), // if you need this
        side: BorderSide(
          color: Color.fromARGB(255, 0, 0, 0).withOpacity(0.2),
          width: 2,
        ),
      ),
      child: Container(
        color: Color.fromARGB(255, 209, 190, 190),
        width: 2000,
        height: 70,
      ),
    ),
  );
}

Widget myImage() {
  return Container(
      width: 200,
      height: 100,
      margin: const EdgeInsets.only(bottom: 20),
      //child: Image.asset('img/1.png'),

      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        color: Colors.white,
        image: const DecorationImage(
          image: AssetImage('poto/apa.png'),
        ),
      ));
}

Widget MyImage1() {
  return Container(
    width: 80,
    height: 100,
    margin: const EdgeInsets.only(bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Colors.white,
      image: DecorationImage(
        image: AssetImage('poto/apa1.png'),
      ),
    ),
  );
}

Widget MyImage2() {
  return Container(
    width: 70,
    height: 100,
    margin: EdgeInsets.only(left: 5, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Colors.white,
      image: DecorationImage(
        image: AssetImage('poto/apa2.png'),
      ),
    ),
  );
}

Widget MyImage3() {
  return Container(
    width: 80,
    height: 100,
    margin: EdgeInsets.only(left: 5, bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Colors.white,
      image: DecorationImage(
        image: AssetImage('poto/one.jpg'),
      ),
    ),
  );
}

Widget MyImage4() {
  return Container(
    width: 200,
    height: 100,
    margin: EdgeInsets.only(left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Colors.white,
      image: DecorationImage(
        image: AssetImage('poto/kawasaki.png'),
      ),
    ),
  );
}

Widget MyImage5() {
  return Container(
    width: 200,
    height: 100,
    margin: EdgeInsets.only(left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Colors.white,
      image: DecorationImage(
        image: AssetImage('poto/ktc.png'),
      ),
    ),
  );
}

Widget MyImage6() {
  return Container(
    width: 200,
    height: 100,
    margin: EdgeInsets.only(left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Colors.white,
      image: DecorationImage(
        image: AssetImage('poto/Ohlins.png'),
      ),
    ),
  );
}

Widget MyImage7() {
  return Container(
    width: 200,
    height: 100,
    margin: EdgeInsets.only(left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Colors.white,
      image: DecorationImage(
        image: AssetImage('poto/829813812.jpg'),
      ),
    ),
  );
}

Widget MyImage8() {
  return Container(
    width: 200,
    height: 100,
    margin: EdgeInsets.only(left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Colors.white,
      image: DecorationImage(
        image: AssetImage('poto/Piaggio.png'),
      ),
    ),
  );
}

Widget MyImage9() {
  return Container(
    width: 200,
    height: 100,
    margin: const EdgeInsets.only(left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Colors.white,
      image: const DecorationImage(
        image: AssetImage('poto/SND.png'),
      ),
    ),
  );
}

Widget MyImage10() {
  return Container(
    width: 200,
    height: 100,
    margin: const EdgeInsets.only(left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Colors.white,
      image: const DecorationImage(
        image: AssetImage('poto/umaracing.png'),
      ),
    ),
  );
}

Widget MyImage11() {
  return Container(
    width: 200,
    height: 100,
    margin: const EdgeInsets.only(left: 10, bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Colors.white,
      image: const DecorationImage(
        image: AssetImage('poto/Suzuki.png'),
      ),
    ),
  );
}

Widget Barang1() {
  return Container(
    width: 200,
    height: 300,
    margin: const EdgeInsets.only(top: 20, left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(255, 26, 26, 26),
      image: const DecorationImage(
        image: AssetImage('poto/1.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 0, 0, 0),
          offset: Offset(1, 1),
          blurRadius: 2,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        padding: EdgeInsets.only(top: 6, left: 6),
        child: Text(
          'New',
          style: TextStyle(
            fontSize: 15,
            color: Color.fromARGB(255, 255, 252, 69),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text('CDI \n Rp.5.560.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget Barang4() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(255, 26, 26, 26),
      image: DecorationImage(
        image: AssetImage('poto/4.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 42, 41, 41),
          offset: Offset(0, 0),
          blurRadius: 10,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        alignment: Alignment.topRight,
        padding: EdgeInsets.only(top: 6, right: 5),
        child: Icon(
          Icons.favorite,
          color: Colors.white,
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text('Silinder Blok \n Rp.5.560.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget Barang5() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(255, 26, 26, 26),
      image: DecorationImage(
        image: AssetImage('poto/5.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 0, 0, 0),
          offset: Offset(0, 0),
          blurRadius: 10,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        padding: EdgeInsets.only(top: 6, left: 2),
        child: Icon(
          Icons.star,
          color: Colors.yellow,
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text('Velg / Rims \n Rp.5.560.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget Barang6() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(255, 26, 26, 26),
      image: DecorationImage(
        image: AssetImage('poto/6.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 108, 105, 105),
          offset: Offset(1, 1),
          blurRadius: 1,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        padding: EdgeInsets.only(top: 6, left: 6),
        child: Text(
          'Discount',
          style: TextStyle(
            fontSize: 15,
            color: Color.fromARGB(255, 255, 252, 69),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      Container(
        alignment: Alignment.topRight,
        padding: EdgeInsets.only(top: 6, right: 5),
        child: Icon(
          Icons.favorite,
          color: Colors.white,
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text('ECU \n Rp.5.560.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget Barang7() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(255, 26, 26, 26),
      image: DecorationImage(
        image: AssetImage('poto/7.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 102, 100, 100),
          offset: Offset(1, 1),
          blurRadius: 1,
        ),
      ],
    ),

    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        padding: EdgeInsets.only(top: 6, left: 2),
        child: Icon(
          Icons.star,
          color: Colors.yellow,
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text('CrankShaft \n Rp.5.560.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget Barang8() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(255, 26, 26, 26),
      image: DecorationImage(
        image: AssetImage('poto/8.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 0, 0, 0),
          offset: Offset(0, 0),
          blurRadius: 10,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        padding: EdgeInsets.only(top: 6, left: 6),
        child: Text(
          'New',
          style: TextStyle(
            fontSize: 15,
            color: Color.fromARGB(255, 255, 252, 69),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      Container(
        alignment: Alignment.topRight,
        padding: EdgeInsets.only(top: 6, right: 5),
        child: Icon(
          Icons.favorite,
          color: Colors.white,
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text('Karburator \n Rp.5.560.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget Barang9() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(255, 26, 26, 26),
      image: DecorationImage(
        image: AssetImage('poto/9.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 97, 97, 97),
          offset: Offset(0, 0),
          blurRadius: 10,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        alignment: Alignment.topRight,
        padding: EdgeInsets.only(top: 6, right: 5),
        child: Icon(
          Icons.favorite,
          color: Colors.white,
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text('Throttle Body \n Rp.5.560.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget Barang10() {
  return Container(
    width: 200,
    height: 300,
    margin: const EdgeInsets.only(top: 20, left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(255, 26, 26, 26),
      image: const DecorationImage(
        image: AssetImage('poto/10.png'),
      ),
      boxShadow: const [
        BoxShadow(
          color: Color.fromARGB(255, 114, 112, 112),
          offset: Offset(1, 1),
          blurRadius: 1,
        ),
      ],
    ),

    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        padding: EdgeInsets.only(top: 6, left: 2),
        child: Icon(
          Icons.star,
          color: Colors.yellow,
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.topRight,
        padding: EdgeInsets.only(top: 6, right: 5),
        child: Icon(
          Icons.favorite,
          color: Colors.white,
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text('Injector \n Rp.5.560.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget TextBawah() {
  return Container(
    padding: EdgeInsets.only(top: 10),
    child: Row(children: [
      Container(
        alignment: Alignment.centerLeft,
        padding: EdgeInsets.only(top: 20, left: 10),
        child: Column(
          children: const <Widget>[
            Text(
              "available items",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 0, 0, 0),
              ),
            ),
          ],
        ),
      ),
      Container(
        alignment: Alignment.centerRight,
        margin: EdgeInsets.only(left: 150, top: 20),
        child: ElevatedButton(
          onPressed: () {},
          child: Text('View All',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 15,
                color: Color.fromARGB(255, 0, 0, 0),
              )),
        ),
      ),
    ]),
  );
}

Widget TextBawah1() {
  return Container(
      child: Column(children: [
    Container(
      width: 290,
      height: 40,
      margin: EdgeInsets.only(left: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Color.fromARGB(235, 255, 255, 255),
        boxShadow: [
          BoxShadow(
            color: Color.fromARGB(255, 0, 0, 0),
            offset: Offset(1, 1),
            blurRadius: 5,
          ),
        ],
      ),
      child: TextField(
        textAlign: TextAlign.center,
        onChanged: (value) {},
        decoration: InputDecoration(
            hintText: 'Type Search for Keyword ',
            hintStyle: TextStyle(color: Color.fromARGB(255, 41, 38, 38)),
            suffixIcon: Icon(Icons.search)),
      ),
    )
  ]));
}

Widget TextBawah2() {
  return Container(
    alignment: Alignment.bottomRight,
    child: Container(
      width: 400,
      height: 70,
      decoration: BoxDecoration(
        color: Colors.transparent,
      ),
      child: Stack(children: [
        Container(
          alignment: Alignment.centerLeft,
          margin: EdgeInsets.only(left: 10),
          child: Text('most popular Katalog',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 0, 0, 0),
              )),
        ),
        Container(
          alignment: Alignment.centerRight,
          margin: EdgeInsets.only(right: 10),
          child: ElevatedButton(
            onPressed: () {},
            child: Text('More',
                style: TextStyle(
                  fontFamily: 'san-serif',
                  fontSize: 20,
                  color: Color.fromARGB(255, 0, 0, 0),
                )),
          ),
        ),
        Container(
          alignment: Alignment.centerRight,
          margin: EdgeInsets.only(right: 10),
          child: ElevatedButton(
            onPressed: () {},
            child: Text('More',
                style: TextStyle(
                  fontFamily: 'san-serif',
                  fontSize: 20,
                  color: Color.fromARGB(255, 0, 0, 0),
                )),
          ),
        ),
        Container(
          alignment: Alignment.centerRight,
          margin: EdgeInsets.only(right: 10),
          child: ElevatedButton(
            onPressed: () {},
            child: Text('More',
                style: TextStyle(
                  fontFamily: 'san-serif',
                  fontSize: 20,
                  color: Color.fromARGB(255, 0, 0, 0),
                )),
          ),
        ),
        Container(
          alignment: Alignment.centerRight,
          margin: EdgeInsets.only(right: 10),
          child: ElevatedButton(
            onPressed: () {},
            child: Text('More',
                style: TextStyle(
                  fontFamily: 'san-serif',
                  fontSize: 20,
                  color: Color.fromARGB(255, 0, 0, 0),
                )),
          ),
        ),
      ]),
    ),
  );
}

Widget katalog() {
  return Container(
    child: Row(
      children: [
        Container(
          alignment: Alignment.centerRight,
          margin: EdgeInsets.only(right: 10),
          child: ElevatedButton(
            onPressed: () {},
            child: Text('More',
                style: TextStyle(
                  fontFamily: 'san-serif',
                  fontSize: 20,
                  color: Color.fromARGB(255, 0, 0, 0),
                )),
          ),
        ),
      ],
    ),
  );
}

class _Second extends State<Second> {
  final TextController tc = Get.put(TextController());
  int _selectedIndex = 0;
  static final List<Widget> _widgetOptions = <Widget>[
    Container(
      decoration: const BoxDecoration(
        color: Color.fromARGB(255, 255, 255, 255),
      ),
      child: Column(
        children: [
          header1(),
          detail1(),
        ],
      ),
    ),
    Container(
      child: Column(
        children: [
          header(),
        ],
      ),
    ),
    Container(
      child: Column(
        children: [profile1()],
      ),
    ),
  ];
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        drawer: Drawer(
          child: ListView(
            children: <Widget>[
              ListTile(
                title: Text('Menu Awal'),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return MyHomePage();
                  }));
                },
              ),
              ListTile(
                  title: Container(child: Text('Menu Login')),
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) {
                      return AddData();
                    }));
                  })
            ],
          ),
          backgroundColor: Color.fromARGB(255, 173, 113, 113),
        ),
        appBar: AppBar(
          elevation: 0,
          title: Text("Hi ${tc.nama.value}"),
          titleTextStyle: TextStyle(
            fontFamily: 'Roboto',
            fontSize: 28,
            color: Color.fromARGB(247, 4, 4, 4),
          ),
          actions: [
            IconButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return AddData();
                  }));
                },
                icon: Icon(Icons.person)),
          ],
          backgroundColor: Color.fromARGB(247, 255, 48, 48),
        ),
        bottomNavigationBar: BottomNavigationBar(
            currentIndex: _selectedIndex,
            onTap: (int index) {
              setState(() {
                _selectedIndex = index;
              });
            },
            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.home),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.message),
                label: 'message',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.person),
                label: 'profile',
              ),
            ]),
        body: _widgetOptions.elementAt(_selectedIndex),
      ),
    );
  }
}

class all extends StatelessWidget {
  const all({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    var tinggi = MediaQuery.of(context).size.height;

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return Second();
              }));
            },
            color: Color.fromARGB(255, 0, 0, 0),
          ),
          title: const Text('Taufiq J.K.'),
          titleTextStyle: TextStyle(
            fontFamily: 'Roboto',
            fontSize: 28,
            color: Color.fromARGB(247, 4, 4, 4),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.shopping_cart),
              color: Color.fromARGB(255, 19, 18, 18),
              onPressed: () {},
            ),
          ],
          backgroundColor: Color.fromARGB(247, 254, 251, 251),
        ),
        body: Container(
          alignment: Alignment.topLeft,
          width: lebar,
          height: tinggi,
          decoration: const BoxDecoration(
            color: Color.fromARGB(255, 255, 255, 255),
          ),
          child: ListView(children: <Widget>[
            TextBawah2(),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Container(
                child: Stack(children: [Myic(context), MyGambar()]),
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Column(
                children: [
                  TextBawah1(),
                  TextBawah(),
                ],
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  Barang1(),
                  Barang4(),
                  Barang5(),
                  Barang6(),
                  Barang7(),
                  Barang8(),
                  Barang9(),
                  Barang10(),
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
