package com.example.posttest5_taufiqjulykurniawan_2009106138

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
