import 'package:flutter/material.dart';

class detail1 extends StatelessWidget {
  const detail1({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Row(children: [
        Expanded(
            child: Column(children: [
          Container(
            height: 300,
            width: 300,
            margin: EdgeInsets.only(left: 100),
            // margin: EdgeInsets.only(bottom: 100),
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: Colors.black,
                  blurRadius: 10,
                  spreadRadius: 1,
                ),
              ],
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                topLeft: Radius.circular(30),
              ),
              image: DecorationImage(
                fit: BoxFit.cover,
                image: AssetImage(
                  'poto/moto.jpg',
                ),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 20),
            child: Row(children: [
              Container(
                margin: EdgeInsets.only(left: 10),
                child: Text('Scrambler Custom',
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.black)),
              ),
              Spacer(),
              Container(
                  margin: EdgeInsets.only(right: 10),
                  child: Text(
                    'Rp.625.000.000',
                  )),
            ]),
          ),
          Container(
            alignment: Alignment.topLeft,
            child: Text('Terbaru : Basic Honda CBR 600RR',
                style: TextStyle(fontSize: 15, color: Colors.black)),
          ),
        ]))
      ]

          // margin: EdgeInsets.only(top: 2),
          // height: 179,
          // width: 400,
          // decoration: BoxDecoration(color: Color.fromARGB(255, 255, 255, 255)),
          ),
    ]);
  }
}
