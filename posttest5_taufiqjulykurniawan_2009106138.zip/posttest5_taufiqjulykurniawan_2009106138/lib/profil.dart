import 'package:flutter/material.dart';

class profile1 extends StatelessWidget {
  const profile1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        child: Column(children: [prof1(), prof2(), prof3(), prof4()]));
  }
}

Widget prof1() {
  return Container(
      child: Column(children: [
    Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Row(
            children: [
              Container(
                margin: EdgeInsets.only(left: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
                child: IconButton(
                    icon: Icon(
                      Icons.note,
                      size: 20,
                      color: Colors.blue,
                    ),
                    onPressed: () {}),
              ),
              Container(
                child: Text('Pesanan Saya'),
              ),
              Container(
                margin: EdgeInsets.only(left: 90),
                child: Text('Riwayat Pesanan'),
              ),
              IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.arrow_forward_ios,
                    size: 20,
                    color: Colors.blue,
                  )),
            ],
          ),
        ),
      ],
    ),
    Container(
      child: Row(
        children: [
          Container(
            alignment: Alignment.center,
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Color.fromARGB(255, 255, 255, 255),
                  ),
                  child: IconButton(
                      icon: Icon(
                        Icons.email,
                        size: 30,
                      ),
                      onPressed: () {}),
                ),
                Container(
                  child: Text('Email'),
                )
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(left: 30, right: 30),
            child: Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Color.fromARGB(255, 255, 255, 255),
                  ),
                  child: IconButton(
                      icon: Icon(
                        Icons.card_giftcard,
                        size: 30,
                      ),
                      onPressed: () {}),
                ),
                Container(
                  child: Text('Dikemas'),
                )
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(right: 30),
            child: Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Color.fromARGB(255, 255, 255, 255),
                  ),
                  child: IconButton(
                      icon: Icon(
                        Icons.car_repair,
                        size: 30,
                      ),
                      onPressed: () {}),
                ),
                Container(
                  child: Text('DiKirim'),
                )
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(right: 30),
            child: Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Color.fromARGB(255, 255, 255, 255),
                  ),
                  child: IconButton(
                      icon: Icon(
                        Icons.star,
                        size: 30,
                      ),
                      onPressed: () {}),
                ),
                Container(
                  child: Text('Nilai'),
                ),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(right: 5),
            child: Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Color.fromARGB(255, 255, 255, 255),
                  ),
                  child: IconButton(
                      icon: Icon(
                        Icons.money,
                        size: 30,
                      ),
                      onPressed: () {}),
                ),
                Container(
                  child: Text('Uang'),
                )
              ],
            ),
          ),
        ],
      ),
    )
  ]));
}

Widget prof2() {
  return Container(
      margin: EdgeInsets.only(top: 40),
      child: Column(children: [
        Row(
          children: [
            Container(
              alignment: Alignment.center,
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Color.fromARGB(255, 255, 255, 255),
                    ),
                    child: IconButton(
                        icon: Icon(
                          Icons.store,
                          size: 20,
                          color: Color.fromARGB(255, 246, 162, 45),
                        ),
                        onPressed: () {}),
                  ),
                  Container(
                    child: Text('Dompet'),
                  ),
                ],
              ),
            ),
          ],
        ),
        Container(
          child: Row(
            children: [
              Container(
                alignment: Alignment.center,
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(left: 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                      child: IconButton(
                          icon: Icon(
                            Icons.attach_money,
                            size: 30,
                          ),
                          onPressed: () {}),
                    ),
                    Container(
                      child: Text('Uang'),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 30, right: 30),
                child: Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                      child: IconButton(
                          icon: Icon(
                            Icons.card_giftcard,
                            size: 30,
                          ),
                          onPressed: () {}),
                    ),
                    Container(
                      child: Text('Dikemas'),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(right: 30),
                child: Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                      child: IconButton(
                          icon: Icon(
                            Icons.car_repair,
                            size: 30,
                          ),
                          onPressed: () {}),
                    ),
                    Container(
                      child: Text('DiKirim'),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(right: 30),
                child: Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                      child: IconButton(
                          icon: Icon(
                            Icons.star,
                            size: 30,
                          ),
                          onPressed: () {}),
                    ),
                    Container(
                      child: Text('Nilai'),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(right: 5),
                child: Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                      child: IconButton(
                          icon: Icon(
                            Icons.money,
                            size: 30,
                          ),
                          onPressed: () {}),
                    ),
                    Container(
                      child: Text('Uang'),
                    )
                  ],
                ),
              ),
            ],
          ),
        )
      ]));
}

Widget prof3() {
  return Container(
      margin: EdgeInsets.only(top: 40),
      child: Column(children: [
        Row(
          children: [
            Container(
              alignment: Alignment.center,
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Color.fromARGB(255, 255, 255, 255),
                    ),
                    child: IconButton(
                        icon: Icon(
                          Icons.shop,
                          size: 20,
                          color: Color.fromARGB(255, 248, 119, 54),
                        ),
                        onPressed: () {}),
                  ),
                  Container(
                    child: Text('Sudah di beli'),
                  ),
                ],
              ),
            ),
          ],
        ),
        Container(
          child: Row(
            children: [
              Container(
                alignment: Alignment.center,
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(left: 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                      child: Image.asset(
                        'poto/1.png',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    Container(
                      child: Text('Rp.500.000'),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 30, right: 30),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(left: 30),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                      child: Image.asset(
                        'poto/1.png',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    Container(
                      child: Text('Rp.500.000'),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(right: 30),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(left: 30),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                      child: Image.asset(
                        'poto/1.png',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    Container(
                      child: Text('Rp.500.000'),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(right: 1),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(left: 30),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                      child: Image.asset(
                        'poto/1.png',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    Container(
                      child: Text('Rp.500.000'),
                    )
                  ],
                ),
              ),
            ],
          ),
        )
      ]));
}

Widget prof4() {
  return Container(
      margin: EdgeInsets.only(top: 40),
      child: Column(children: [
        Row(
          children: [
            Container(
              alignment: Alignment.center,
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Color.fromARGB(255, 255, 255, 255),
                    ),
                    child: IconButton(
                        icon: Icon(
                          Icons.favorite,
                          size: 20,
                          color: Colors.blue,
                        ),
                        onPressed: () {}),
                  ),
                  Container(
                    child: Text('Sering Dilihat'),
                  ),
                ],
              ),
            ),
          ],
        ),
        Container(
          child: Row(
            children: [
              Container(
                margin: EdgeInsets.only(right: 30),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(left: 30),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                      child: Image.asset(
                        'poto/1.png',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    Container(
                      child: Text('Rp.500.000'),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(right: 30),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(left: 30),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                      child: Image.asset(
                        'poto/1.png',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    Container(
                      child: Text('Rp.500.000'),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(right: 30),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(left: 30),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                      child: Image.asset(
                        'poto/1.png',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    Container(
                      child: Text('Rp.500.000'),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(right: 0),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(left: 0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                      child: Image.asset(
                        'poto/2.png',
                        width: 30,
                        height: 30,
                      ),
                    ),
                    Container(
                      child: Text('Rp.500.000'),
                    )
                  ],
                ),
              ),
            ],
          ),
        )
      ]));
}
