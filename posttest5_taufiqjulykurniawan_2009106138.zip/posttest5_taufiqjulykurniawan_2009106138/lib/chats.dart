import 'package:flutter/material.dart';

class title extends StatelessWidget {
  const title({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 10),
      height: 50,
      child: Stack(
        children: [
          Row(children: [
            Container(
              margin: EdgeInsets.only(left: 10, top: 10),
              alignment: Alignment.centerLeft,
              child: Text('Chats',
                  style: TextStyle(
                    shadows: [
                      Shadow(
                        blurRadius: 3,
                        color: Colors.black,
                        offset: Offset(1, 1),
                      ),
                    ],
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.red,
                  )),
            ),
            Spacer(),
            Positioned(
              child: Container(
                margin: EdgeInsets.only(right: 10, top: 20),
                height: 30,
                width: 60,
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: Color.fromARGB(255, 6, 6, 6),
                    blurRadius: 3,
                    offset: Offset(0, 5),
                  )
                ], color: Colors.red, borderRadius: BorderRadius.circular(20)),
                child: TextButton(
                  onPressed: () {},
                  child: Text('all',
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Roboto',
                          color: Color.fromARGB(255, 255, 255, 255))),
                ),
              ),
            ),
          ])
        ],
      ),
    );
  }
}

class chat extends StatelessWidget {
  const chat({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          chat0(),
          chat1(),
          chat2(),
          chat3(),
          chat4(),
          chat5(),
          chat6(),
          chat7()
        ],
      ),
    );
  }
}

Widget chat0() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 30),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'poto/yaoming.jpg',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Aming',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 230, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('2',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Typing....',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('20:21',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat1() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'poto/ucup.jpg',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Faruk',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 235, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('1',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Kapan Barang Di Kirim ?',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('01:07',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat2() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'poto/chloe.jpeg',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Dono CS',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 210, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('5',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Pengiriman Cepat',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('19:21',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat3() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'poto/duduk.jpg',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Nando ',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 220, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('1',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Cek harga dulu min....',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('13:15',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat4() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'poto/hmm.jpg',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Fahrul',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 230, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('3',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Ada kah min?',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('10:21',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat5() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'poto/jarjit.jpg',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Pitung S',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 210, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('3',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('ECU merk lain adakah ?',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('20:19',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat6() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'poto/brian.jpg',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Seto ',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 230, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('4',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Velgnya min',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('20:21',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat7() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          child: Column(children: [
            Container(
              margin: EdgeInsets.only(left: 260, top: 10),
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                  color: Colors.red, borderRadius: BorderRadius.circular(20)),
              child: TextButton(
                  onPressed: () {},
                  child: Container(
                    alignment: Alignment.center,
                    margin: EdgeInsets.only(bottom: 5),
                    child: Text('+',
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  )),
            ),
          ])));
}

Widget chat8() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'produk/putri.png',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Putri',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 250, top: 5),
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('2',
                        style: TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Laptop Acer Ada kah....',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('21:21',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}
