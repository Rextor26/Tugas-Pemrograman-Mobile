package com.example.taufiqjulykurniawan_pmobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
